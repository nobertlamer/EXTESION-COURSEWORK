#!/bin/sh
git subtree pull --prefix lib/css-shapes-editor git@github.com:adobe-webplatform/css-shapes-editor.git master --squash
